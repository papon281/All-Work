package scheduling.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FileResponse {
    private String fileName;
    private String fileUri;
    private String fileType;
    private Long fileSize;

    public static FileResponse from(String name, String uri, String type, Long size){
        return FileResponse.builder()
                .fileName(name)
                .fileUri(uri)
                .fileType(type)
                .fileSize(size)
                .build();
    }
}
