package scheduling.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import scheduling.exception.FileStorageException;
import scheduling.exception.MyFileNotFoundException;
import scheduling.response.FileResponse;
import scheduling.service.FileService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

@Service
public class FileServiceImpl implements FileService {
    @Value("${file.directory}")
    private String fileDirectory;

    @Override
    public String uploadFile(MultipartFile file) {
        String fileName = file.getOriginalFilename();
        File file1 = new File(fileName);
        Path filePath = Path.of(fileDirectory + file1);
        try {
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        } catch (IOException ex) {
            throw new FileStorageException("File not stored. " + ex.getMessage());
        }
    }

    @Override
    public Resource downloadFile(String fileName) {
        final Path[] found = {null};
        Path path = Paths.get(fileDirectory);
        try {
            Files.list(path).forEach(file -> {
                if (file.endsWith(fileName)) {
                    found[0] = file;
                }
            });
            return new UrlResource(found[0].toUri());
        } catch (IOException e) {
            throw new MyFileNotFoundException(e.getMessage());
        }
    }
}
