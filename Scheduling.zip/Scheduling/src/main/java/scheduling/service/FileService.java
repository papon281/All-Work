package scheduling.service;

import com.kenai.jnr.x86asm.OP;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;
import scheduling.response.FileResponse;

import java.util.Optional;

public interface FileService {
    String uploadFile(MultipartFile file);

    Resource downloadFile(String fileName);
}
