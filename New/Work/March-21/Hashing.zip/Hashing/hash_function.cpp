#include <iostream>
#include <stdlib.h>
#include <set>
#include <time.h>
#include <stdio.h>
#include "hash_function.h"

using namespace std;

Hash :: Hash(int _size)
{
    tableSize = _size;
    linearHashTable = new int[_size];
    quadraticHashTable = new int[_size];
    doubleHashTable = new int[_size];
    prime = 7;

    for (int i = 0; i < tableSize; i++)
    {
        linearHashTable[i] = -1;
        quadraticHashTable[i] = -1;
        doubleHashTable[i] = -1;
    }
}

void Hash :: getKey()
{
    int x = 0;
    int cnt = 0;
    while(x < 1100)
    {
        cnt += 100;
        srand(cnt);
        double loadFactor = (double)(distinct.size()) / (double) (tableSize);
        cout<<loadFactor<<endl;
        if(loadFactor > 0.5)
        {
            rehash();
        }
        int key = rand() % 999999999 + 1;
        if(distinct.find(key)== distinct.end())
        {
            distinct.insert(key);
            linearInsert(key);
            quadraticInsert(key);
            doubleInsert(key);
            x++;
        }
    }
}

int Hash :: hash_fct(int k, int m)
{
    return (k % m);
}

int Hash :: _hash(int key)
{
    return (prime - (key % prime));
}

void Hash :: linearInsert(int key)
{
    int index = hash_fct(key, tableSize);
    while(linearHashTable[index] != -1)
    {
        index++;
        index = index % tableSize;
    }
    linearHashTable[index] = key;
}

int Hash :: linearSearch(int key)
{
    int index = hash_fct(key, tableSize);

    while(linearHashTable[index] != -1)
    {
        if(linearHashTable[index] == key)
        {
            return linearHashTable[index];
            break;
        }
        index++;
        index = index % tableSize;
    }
    return -1;
}

void Hash :: quadraticInsert(int key)
{
    int index = hash_fct(key, tableSize);
    int i = 1;
    while(quadraticHashTable[index] != -1)
    {
        index = index + (i * i);
        index = index % tableSize;
        i++;
    }
    quadraticHashTable[index] = key;
}

int Hash :: quadraticSearch(int key)
{
    int index = hash_fct(key, tableSize);
    int i = 1;
    while(quadraticHashTable[index] != -1)
    {
        if(quadraticHashTable[index] == key)
        {
            return quadraticHashTable[index];
            break;
        }
        index = (index + (i * i)) % tableSize;
        i++;
    }
    return -1;
}

void Hash :: doubleInsert(int key)
{
    int index = hash_fct(key, tableSize);
    int index1 = _hash(key);
    int i = 1;

    while(doubleHashTable[index] != -1)
    {
        index = (index + (i * index1)) % tableSize;
        i++;
    }
    doubleHashTable[index] = key;
}

int Hash :: doubleSearch(int key)
{
    int index = hash_fct(key, tableSize);
    int index1 = _hash(key);
    int i = 1;

    while(doubleHashTable[index] != -1)
    {
        if(doubleHashTable[index] == key)
        {
            return doubleHashTable[index];

        }
        index = (index + (i * index)) % tableSize;
        i++;
    }

    return -1;
}

void Hash :: rehash()
{
    int oldSize = tableSize;
    tableSize = (tableSize * 2) + 1;
    int* newLinearTable = new int[tableSize];
    int* newQuadraticTable = new int[tableSize];
    int* newDoubleTable = new int[tableSize];

    for(int i = 0 ; i < tableSize ; i++)
    {
        newLinearTable[i] = -1;
        newQuadraticTable[i] = -1;
        newDoubleTable[i] = -1;
    }

    for(int i = 0; i < oldSize; i++)
    {
        if(linearHashTable[i] != -1)
        {
            int index = hash_fct(linearHashTable[i], tableSize);
            while(newLinearTable[index] != -1)
            {
                index++;
                index = index % tableSize;
            }
            newLinearTable[index] = linearHashTable[i];
        }
    }
    linearHashTable = newLinearTable;
    delete[] newLinearTable;

    for(int i = 0; i < oldSize; i++)
    {
        if(quadraticHashTable[i] != -1)
        {
            int index = hash_fct(quadraticHashTable[i], tableSize);
            int j = 1;
            while(newQuadraticTable[index] != -1)
            {
                index = (index + (j * j)) % tableSize;
                j++;
            }
            newQuadraticTable[index] = quadraticHashTable[i];
        }
    }
    quadraticHashTable = newQuadraticTable;
    delete[] newQuadraticTable;

    for(int i = 0; i < oldSize; i++)
    {
        if(doubleHashTable[i] != -1)
        {
            int index = hash_fct(doubleHashTable[i], tableSize);
            int index1 = _hash(doubleHashTable[i]);
            int j = 1;
            while(newDoubleTable[index] != -1)
            {

                index = (index + (j * index1)) % tableSize;
                j++;
            }
            newDoubleTable[index] = doubleHashTable[i];
        }
    }
    doubleHashTable = newDoubleTable;
    delete[] newDoubleTable;
}
